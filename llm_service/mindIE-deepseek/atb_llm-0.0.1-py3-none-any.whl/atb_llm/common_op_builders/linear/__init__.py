# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
from atb_llm.common_op_builders.common_op_builder_manager import CommonOpBuilderManager
from atb_llm.common_op_builders.linear.fp_linear_common_op_builder import FpLinearCommonOpBuilder
from atb_llm.common_op_builders.linear.atb_quant_linear_common_op_builder import ATBQuantLinearCommonOpBuilder
from atb_llm.common_op_builders.linear.aclnn_quant_batch_linear_common_op_builder import \
    ACLNNQuantBatchLinearCommonOpBuilder


CommonOpBuilderManager.register(ACLNNQuantBatchLinearCommonOpBuilder)
CommonOpBuilderManager.register(ATBQuantLinearCommonOpBuilder)
CommonOpBuilderManager.register(FpLinearCommonOpBuilder)
