# Copyright (c) Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
from .normalization import RmsNorm
from .linear.linear import Linear